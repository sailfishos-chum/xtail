@BOTTOM@

/* $Id: acconfig.h,v 1.1 2000/06/04 04:52:54 chip Exp $ */

#ifdef __STDC__
# define VOID void
#else
# define VOID char
#endif

